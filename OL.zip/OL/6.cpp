/*************************************************************************
	> File Name: 6.cpp
	> Author: 
	> Mail: 
	> Created Time: 2020年06月08日 星期一 10时28分50秒
 ************************************************************************/

#include<iostream>
using namespace std;


int main(){
    int sum1 = 5050;
    int sum2 = (2 * 100 * 100 + 3 * 100 * 100 + 100) / 6;
    cout << sum1 * sum1 - sum2;
    return 0;
}
